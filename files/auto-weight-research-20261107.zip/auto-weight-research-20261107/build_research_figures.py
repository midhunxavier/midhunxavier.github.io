"""Draw publication figures from archived statistics, without new inference.

python build_research_figures.py --data DATA_DIR --output FIGURE_DIR
Requires matplotlib==3.11.2. Exports desktop and mobile SVG/PNG/PDF figures.
"""
from pathlib import Path
import argparse
import csv
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

INK='#20352f'; MUTED='#60716c'; BLUE='#2865b0'; GREEN='#167a65'
GREY='#a9b5b1'; ORANGE='#b95732'; PAPER='#fafaf7'; GRID='#dde3df'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':12,
 'text.color':INK,'axes.labelcolor':MUTED,'xtick.color':MUTED,
 'axes.spines.top':False,'axes.spines.right':False,'axes.spines.left':False,
 'axes.spines.bottom':False,'figure.facecolor':PAPER,'axes.facecolor':PAPER,
 'svg.fonttype':'path','svg.hashsalt':'autoweight-editorial-v2','pdf.fonttype':42})


def save(fig, output, name, mobile):
    name += '-mobile' if mobile else ''
    for ext in ['svg','png','pdf']:
        p=output/f'{name}.{ext}'
        fig.savefig(p,dpi=200,metadata={'Creator':'AutoWeight research note'})
        if ext=='svg':p.write_text('\n'.join(x.rstrip() for x in p.read_text().splitlines())+'\n')
    plt.close(fig)


def heading(fig, number, subject, title, mobile):
    fig.text(.07,.96,f'{number}  /  {subject.upper()}',color=GREEN,fontsize=10,weight='bold')
    fig.text(.07,.91,title,fontsize=17 if mobile else 21,weight='bold',va='top',linespacing=1.25)


def clean_axis(ax, xmax, xlabel):
    ax.set_xlim(0,xmax); ax.set_yticks([])
    ax.tick_params(axis='x',length=0,labelsize=11)
    ax.grid(axis='x',color=GRID,linewidth=.6);ax.set_axisbelow(True)
    ax.set_xlabel(xlabel,fontsize=11,labelpad=12)


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--data',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    args.output.mkdir(parents=True,exist_ok=True)
    rows=list(csv.DictReader((args.data/'gate-results.csv').open()))
    cart=json.loads((args.data/'cartpole-analysis.json').read_text())
    def row(case,attempt,group):
        found=[r for r in rows if r['case']==case and r['attempt']==attempt and r['group']==group and r['stage']!='development']
        assert len(found)==1,(case,attempt,group)
        return found[0]
    for mobile in [False,True]:
        fig=plt.figure(figsize=(4.8,8.4) if mobile else (8.6,6.6))
        heading(fig,'01','CartPole','The gain is real.\nThe baseline matters.' if mobile else 'The gain is real. The baseline matters.',mobile)
        ax=fig.add_axes([.07,.18,.86,.58 if mobile else .59])
        methods=[('original_stochastic','Original policy',GREY),
          ('output_only_3','Logit gain only',GREY),('original_argmax','Original + argmax',GREY),
          ('angle_only_12','Angle gain only',GREY),('accepted_12_3','Astra edit',BLUE),
          ('automatic_winner','Informed numerical grid',GREEN),('accepted_argmax','Astra edit + argmax*',GREY)]
        for i,(key,label,color) in enumerate(methods):
            v=cart['methods'][key];y=6-i;m=v['mean'];lo,hi=v['ci95']
            ax.barh(y,m,height=.32,color=color,zorder=2)
            ax.errorbar(m,y,xerr=[[m-lo],[hi-m]],fmt='none',color=INK,capsize=3,linewidth=1,zorder=3)
            ax.text(0,y+.27,label,fontsize=12 if mobile else 13,weight='bold' if color in [BLUE,GREEN] else 'normal')
            ax.text(500,y+.27,f'{m:.2f}',ha='right',fontsize=12 if mobile else 13,weight='bold',color=INK)
        ax.set_ylim(-.5,6.85);clean_axis(ax,500,'Mean return · higher is better')
        ax.set_xticks([0,100,200,300,400,500])
        fig.text(.07,.035,'1,024 fresh seeds per policy\nWhiskers: descriptive 95% intervals',fontsize=10,color=MUTED,linespacing=1.5)
        save(fig,args.output,'cartpole-controls',mobile)

        fig=plt.figure(figsize=(4.8,8.8) if mobile else (8.6,5.4))
        heading(fig,'02','SmolLM2','Science recovers.\nInstructions slip.' if mobile else 'Science recovers. Instructions slip.',mobile)
        methods=[('instruct','Original instruct',GREY),('astra-L1','Layer-wise blend',BLUE),
                 ('blend-15','Uniform 15% blend',GREY),('rollback','Full rollback',ORANGE)]
        panels=[('arc','Science questions','1,280 ARC questions'),('instruction','Following instructions','512 prompts')]
        for k,(group,title,sample) in enumerate(panels):
            rect=([.08,.51,.84,.23] if k==0 else [.08,.16,.84,.23]) if mobile else [.07+k*.47,.23,.39,.45]
            ax=fig.add_axes(rect)
            ax.set_title(title+'\n'+sample,loc='left',fontsize=12 if mobile else 13,weight='bold',pad=17,linespacing=1.6)
            for i,(attempt,label,color) in enumerate(methods):
                v=row('public-smollm2-layer-blend',attempt,group);value=float(v['candidate'])*100;y=3-i
                ax.barh(y,value,height=.33,color=color,zorder=2)
                ax.text(0,y+.27,label,fontsize=11)
                ax.text(60,y+.27,f'{value:.2f}%',ha='right',fontsize=11,weight='bold')
            ax.set_ylim(-.5,3.75);clean_axis(ax,60,'' if mobile and k==0 else 'Accuracy (%)');ax.set_xticks([0,20,40,60])
        fig.text(.07,.035,'Accuracy on the same fresh holdout.\nPoint estimates; see text for acceptance.',fontsize=10,color=MUTED,linespacing=1.5)
        save(fig,args.output,'smollm2-gates',mobile)

        fig=plt.figure(figsize=(4.8,6.6) if mobile else (8.6,5.6))
        heading(fig,'03','MountainCar','Same edit.\nStronger evidence.' if mobile else 'Same edit. Stronger evidence.',mobile)
        ax=fig.add_axes([.08,.22,.84,.45 if mobile else .48])
        ax.axvspan(-2,1,color=GREEN,alpha=.07)
        ax.axvline(-2,color=GREEN,linestyle='--',linewidth=1.5)
        for y,case,attempt,label,color in [(1,'mountaincar','003','First test · 128 episodes/group',ORANGE),
                                          (0,'mountaincar-retest','001','Fresh retest · 1,024/group',GREEN)]:
            v=row(case,attempt,'other_starts');lower=float(v['lower_bound'])
            ax.hlines(y,-3.1,1,color=GRID,linewidth=1)
            ax.plot(lower,y,'o',markersize=11,color=color)
            ax.text(-3.1,y+.38,label,fontsize=11 if mobile else 13,weight='bold')
            ax.annotate(f'{lower:+.3f}  ·  '+('PASS' if lower>=-2 else 'FAIL'),(lower,y),
              xytext=(0,-24),textcoords='offset points',ha='center',color=color,fontsize=12,weight='bold')
        ax.set(xlim=(-3.15,1.1),ylim=(-.5,1.7),yticks=[],xticks=[-3,-2,-1,0,1])
        ax.tick_params(axis='x',length=0,labelsize=11)
        ax.set_xlabel('Preservation lower bound (return)',fontsize=11,labelpad=13)
        fig.text(.08,.10,'Required: −2 or higher',color=GREEN,fontsize=12,weight='bold')
        fig.text(.08,.035,'Separate tests; the earlier failure remains recorded.',fontsize=9 if mobile else 11,color=MUTED)
        save(fig,args.output,'mountaincar-retest',mobile)

if __name__=='__main__':main()
