"""Render archived AutoWeight observations; never run models or recompute inference.

Usage: python build_research_figures.py --data DATA_DIR --output FIGURE_DIR
DATA_DIR contains gate-results.csv and cartpole-analysis.json.
Requires matplotlib 3.11.2. Output includes SVG, PNG and PDF for each figure.
"""
from pathlib import Path
import argparse
import csv
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

BLUE, TEAL, ORANGE, GREY = '#2563a6', '#087f74', '#bd522d', '#64748b'
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 11,
                     'axes.spines.top': False, 'axes.spines.right': False,
                     'axes.spines.left': False, 'axes.edgecolor': '#cbd5e1',
                     'axes.labelcolor': '#334155', 'text.color': '#172b40',
                     'xtick.color': '#475569', 'ytick.color': '#172b40',
                     'svg.fonttype': 'path', 'svg.hashsalt': 'autoweight-20261107',
                     'pdf.fonttype': 42, 'figure.facecolor': 'white',
                     'axes.facecolor': 'white'})


def save(fig, output, name):
    for extension in ['svg', 'png', 'pdf']:
        fig.savefig(output / f'{name}.{extension}', dpi=200,
                    metadata={'Creator': 'AutoWeight research note'})
        if extension == 'svg':
            path = output / f'{name}.{extension}'
            path.write_text('\n'.join(line.rstrip() for line in path.read_text().splitlines()) + '\n')
    plt.close(fig)


def style(ax):
    ax.grid(axis='x', color='#e2e8f0', linewidth=.7, zorder=0)
    ax.tick_params(axis='y', length=0, pad=10)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    rows = list(csv.DictReader((args.data / 'gate-results.csv').open()))
    cart = json.loads((args.data / 'cartpole-analysis.json').read_text())

    # Per-method 95% intervals are descriptive. The text reports the distinct,
    # simultaneous 99% paired contrasts used for superiority decisions.
    methods = [
        ('original_stochastic', 'Original · stochastic', GREY),
        ('output_only_3', 'Logit gain only · ×3', GREY),
        ('original_argmax', 'Original · argmax', GREY),
        ('angle_only_12', 'Angle gain only · ×12', GREY),
        ('accepted_12_3', 'Astra edit · gains 12, 3', BLUE),
        ('automatic_winner', 'Informed grid · gains 12, 6', TEAL),
        ('accepted_argmax', 'Astra edit · argmax*', GREY)]
    fig, ax = plt.subplots(figsize=(10, 5.8))
    fig.subplots_adjust(left=.32, right=.90, top=.79, bottom=.17)
    fig.text(.04, .94, 'A large gain survives — a stronger control scores higher',
             fontsize=16, weight='bold')
    fig.text(.04, .88, 'CartPole · 1,024 fresh shared seeds per method · 500-step limit', fontsize=11)
    for i, (key, label, color) in enumerate(methods):
        v = cart['methods'][key]; mean = v['mean']; lo, hi = v['ci95']
        ax.errorbar(mean, i, xerr=[[mean-lo], [hi-mean]], fmt='o',
                    color=color, capsize=4, markersize=7, linewidth=2, zorder=3)
        ax.text(519, i, f'{mean:.2f}', va='center', ha='left', color=color, fontsize=11)
    ax.set(yticks=range(7), yticklabels=[m[1] for m in methods], xlim=(0, 510),
           xlabel='Mean episode return (higher is better)', ylim=(6.55, -.55))
    style(ax)
    fig.text(.04, .045, 'Bars: descriptive 95% bootstrap intervals. *Argmax edit is descriptive, outside the prespecified contrasts.', fontsize=9)
    save(fig, args.output, 'cartpole-controls')

    def row(case, attempt, group):
        found = [r for r in rows if r['case'] == case and r['attempt'] == attempt
                 and r['group'] == group and r['stage'] != 'development']
        assert len(found) == 1, (case, attempt, group)
        return found[0]

    fig, axes = plt.subplots(2, 1, figsize=(10, 7.5))
    fig.subplots_adjust(left=.24, right=.94, top=.79, bottom=.18, hspace=.8)
    fig.text(.04, .95, 'Recovering science accuracy also changes instruction following', fontsize=15, weight='bold')
    fig.text(.04, .90, 'SmolLM2 · fresh confirmation · each change is relative to the instruct checkpoint', fontsize=11)
    edits = [('astra-L1', 'Layer-wise blend', BLUE), ('blend-15', 'Uniform 15% blend', GREY),
             ('rollback', 'Full rollback', ORANGE)]
    for ax, group, title, limits in zip(axes, ['arc', 'instruction'],
            ['A  ARC accuracy · 1,280 questions', 'B  Strict instruction compliance · 512 prompts'],
            [(-1, 16), (-27, 3)]):
        gate = 2 if group == 'arc' else -5
        ax.axvspan(gate, limits[1], color=TEAL, alpha=.045)
        ax.axvline(gate, color=TEAL, linestyle='--', linewidth=1.3)
        ax.axvline(0, color='#cbd5e1', linewidth=.8)
        for i, (key, label, color) in enumerate(edits):
            v = row('public-smollm2-layer-blend', key, group)
            mean, lower = float(v['gate_delta'])*100, float(v['lower_bound'])*100
            ax.plot([lower, mean], [i, i], color=color, linewidth=2)
            ax.plot(mean, i, 'o', color=color, markersize=7)
            ax.plot(lower, i, '|', color=color, markersize=14, markeredgewidth=2)
            ax.annotate(f'{mean:+.2f}', (mean, i), xytext=(7, -3), textcoords='offset points', color=color, fontsize=10)
        ax.set(yticks=range(3), yticklabels=[m[1] for m in edits], xlim=limits,
               ylim=(2.6, -.65), xlabel='Change in percentage points')
        ax.set_title(title, loc='left', fontsize=12, pad=12)
        style(ax)
    fig.text(.04, .10, 'Point = observed change    | = one-sided lower bound    Dashed line = required lower bound', fontsize=10)
    fig.text(.04, .045, 'Selected blend: instruction bound −5.0049 pp vs required −5 pp → rejected. Segments are not two-sided CIs.', fontsize=10)
    save(fig, args.output, 'smollm2-gates')

    fig, axes = plt.subplots(2, 1, figsize=(10, 7.2))
    fig.subplots_adjust(left=.27, right=.94, top=.79, bottom=.18, hspace=.85)
    fig.text(.04, .95, 'The same MountainCar edit fails once and passes a fresh retest', fontsize=15, weight='bold')
    fig.text(.04, .90, 'Candidate bytes and gate thresholds are identical · both outcomes remain part of the record', fontsize=11)
    for ax, group, title, limits, gate in zip(axes, ['central_start', 'other_starts'],
            ['A  Target return', 'B  Preservation return'], [(0, 12), (-3.4, 3)], [5, -2]):
        ax.axvline(gate, color=TEAL, linestyle='--', linewidth=1.3)
        ax.axvspan(gate, limits[1], color=TEAL, alpha=.045)
        ax.axvline(0, color='#cbd5e1', linewidth=.8)
        for i, (case, attempt, color) in enumerate([('mountaincar', '003', ORANGE), ('mountaincar-retest', '001', TEAL)]):
            v = row(case, attempt, group)
            mean, lower = float(v['gate_delta']), float(v['lower_bound'])
            ax.plot([lower, mean], [i, i], color=color, linewidth=2)
            ax.plot(mean, i, 'o', color=color, markersize=7)
            ax.plot(lower, i, '|', color=color, markersize=14, markeredgewidth=2)
            ax.annotate(f'{mean:+.2f}', (mean, i), xytext=(8, -3), textcoords='offset points', color=color)
        ax.set(yticks=[0,1], yticklabels=['Original test\n128 episodes / group', 'Fresh retest\n1,024 episodes / group'],
               xlim=limits, ylim=(1.5, -.5), xlabel='Change in mean return (higher is better)')
        ax.set_title(title, loc='left', fontsize=12, pad=12); style(ax)
    fig.text(.04, .10, 'Point = observed change    | = one-sided lower bound    Dashed line = required lower bound', fontsize=10)
    fig.text(.04, .045, 'Separate tests, 4,096 bootstrap draws each. No joint error guarantee across this failure-triggered retest.', fontsize=10)
    save(fig, args.output, 'mountaincar-retest')


if __name__ == '__main__':
    main()
