# Can You Fix a Model by Editing Its Weights? — research supplement

Midhun Xavier, 7 November 2026.

This package reproduces the three published figures from archived summary
statistics. It does not run a model, simulator, bootstrap, or candidate search.
It is not a standalone inference reproduction package: source checkpoints,
raw model observations, dataset assets, evaluator environments and complete
agent transcripts are not bundled. Source hashes identify the audited artifacts.

## Contents

- `gate-results.csv`: all 377 extracted gate rows, including failures. Development,
  confirmation, and diagnostic/control comparisons are distinguished by `stage`.
  `lower_bound` is the recorded one-sided bound, not a two-sided interval.
  `gate_delta` reverses sign for lower-is-better metrics such as NLL.
- `cartpole-analysis.json`: the seven-method fresh comparison, descriptive 95%
  intervals, simultaneous 99% paired contrasts, and search work accounting.
- `case-catalogue.json`: 14 external runs/cohorts, gates, dataset/evaluator
  identities, trial outcomes and confirmation results. This derived summary
  omits local artifact paths; it is not a new sealed report.
- `figures/`: SVG, PNG, and PDF versions of all three figures.
- `build_research_figures.py`: plotting code.
- `provenance.json`: original source hashes and artifact-audit scope.
- `references.bib`: cited literature.
- `SHA256.json`: checksums of this package's files, excluding the manifest itself.

## Rebuild figures

Use Python with `matplotlib==3.11.2`, then run:

```sh
python build_research_figures.py --data . --output rebuilt-figures
```

The plot marks are deterministic; PDF/SVG metadata may differ by generation time
or library version. No statistical estimates are recomputed.

## Interpretation

The three local SmolLM2 studies share a model pair. CartPole controls and the
MountainCar retest are follow-ups, not independent case families. There is no
pooled success-rate claim or joint error guarantee across this collection.
The original MountainCar rejection is retained. Qwen2's four recorded attempts
do not exhaust its six-attempt limit. SmolLM2's first two held-out comparisons
were diagnostic because no development candidate was eligible.

For the layer-blend study, only the selected candidate's two gates determine the
primary confirmation decision. The control rows do not demonstrate superiority
of one edit over another. The blog explains the exact sample provenance,
uncertainty procedures and limitations beside the relevant results.
